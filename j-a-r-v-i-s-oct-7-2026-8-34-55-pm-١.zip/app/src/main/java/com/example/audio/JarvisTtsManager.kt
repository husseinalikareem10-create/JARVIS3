package com.example.audio

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class JarvisTtsManager(
    private val context: Context,
    private val onSpeakingStateChanged: (Boolean) -> Unit
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private var currentPitch = 0.88f // Baritone pitch preset
    private var currentRate = 0.98f
    private var preferredLocale: String = "auto"

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            setupVoice()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                    onSpeakingStateChanged(true)
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    onSpeakingStateChanged(false)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    onSpeakingStateChanged(false)
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _isSpeaking.value = false
                    onSpeakingStateChanged(false)
                    Log.w("JarvisTts", "TTS Error: $errorCode")
                }
            })
        } else {
            Log.e("JarvisTts", "TTS Initialization failed: $status")
        }
    }

    fun updateSettings(pitch: Float, rate: Float, localePref: String) {
        currentPitch = pitch
        currentRate = rate
        preferredLocale = localePref
        applyPitchAndRate()
    }

    private fun applyPitchAndRate() {
        tts?.setPitch(currentPitch)
        tts?.setSpeechRate(currentRate)
    }

    private fun setupVoice() {
        tts?.let { engine ->
            engine.setPitch(currentPitch)
            engine.setSpeechRate(currentRate)
            // Try to find a British or deep male voice
            try {
                val voices = engine.voices
                if (voices != null) {
                    val britishVoice = voices.find { voice ->
                        voice.locale == Locale.UK && voice.name.contains("male", ignoreCase = true)
                    } ?: voices.find { it.locale == Locale.UK }
                    if (britishVoice != null) {
                        engine.voice = britishVoice
                    }
                }
            } catch (e: Exception) {
                Log.w("JarvisTts", "Voice query error: ${e.message}")
            }
        }
    }

    fun speak(text: String, isQueueAdd: Boolean = false) {
        if (!isInitialized || text.isBlank()) return

        val cleanText = sanitizeForSpeech(text)
        if (cleanText.isBlank()) return

        // Detect language if auto
        val isArabic = isArabicText(cleanText)
        if (preferredLocale == "ar" || (preferredLocale == "auto" && isArabic)) {
            val arLocale = Locale.forLanguageTag("ar")
            if ((tts?.isLanguageAvailable(arLocale) ?: -1) >= TextToSpeech.LANG_AVAILABLE) {
                tts?.language = arLocale
            }
        } else {
            val enLocale = Locale.UK
            if ((tts?.isLanguageAvailable(enLocale) ?: -1) >= TextToSpeech.LANG_AVAILABLE) {
                tts?.language = enLocale
            } else {
                tts?.language = Locale.US
            }
        }

        applyPitchAndRate()

        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "jarvis_${System.currentTimeMillis()}")

        val queueMode = if (isQueueAdd) TextToSpeech.QUEUE_ADD else TextToSpeech.QUEUE_FLUSH
        tts?.speak(cleanText, queueMode, params, "jarvis_speech")
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        onSpeakingStateChanged(false)
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }

    private fun isArabicText(text: String): Boolean {
        for (char in text) {
            val ub = Character.UnicodeBlock.of(char)
            if (ub == Character.UnicodeBlock.ARABIC ||
                ub == Character.UnicodeBlock.ARABIC_SUPPLEMENT ||
                ub == Character.UnicodeBlock.ARABIC_PRESENTATION_FORMS_A ||
                ub == Character.UnicodeBlock.ARABIC_PRESENTATION_FORMS_B
            ) {
                return true
            }
        }
        return false
    }

    private fun sanitizeForSpeech(text: String): String {
        // Strip markdown stars, bullets, hashes, emojis, and backticks for pristine TTS delivery
        return text
            .replace(Regex("[*#_`~>|\\[\\]{}()\\-]"), " ")
            .replace(Regex("[\uD83C-\uDBFF\uDC00-\uDFFF]+"), "") // Remove emojis
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
