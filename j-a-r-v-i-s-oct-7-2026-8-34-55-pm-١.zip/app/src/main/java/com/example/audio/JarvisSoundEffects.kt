package com.example.audio

import android.media.AudioManager
import android.media.ToneGenerator
import android.util.Log

class JarvisSoundEffects {
    private var toneGenerator: ToneGenerator? = null

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 65)
        } catch (e: Exception) {
            Log.w("JarvisAudio", "ToneGenerator init failed: ${e.message}")
        }
    }

    fun playActivationBeep() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 80)
        } catch (e: Exception) {
            Log.w("JarvisAudio", "Failed to play beep: ${e.message}")
        }
    }

    fun playAcknowledgeChime() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 120)
        } catch (e: Exception) {
            Log.w("JarvisAudio", "Failed to play chime: ${e.message}")
        }
    }

    fun playStandbyClick() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 50)
        } catch (e: Exception) {
            Log.w("JarvisAudio", "Failed to play click: ${e.message}")
        }
    }

    fun release() {
        toneGenerator?.release()
        toneGenerator = null
    }
}
