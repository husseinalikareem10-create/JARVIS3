package com.example.model

enum class JarvisState {
    STANDBY,
    LISTENING,
    PROCESSING,
    SPEAKING,
    ERROR
}

enum class JarvisLanguage(val code: String, val displayName: String, val ttsLocale: String) {
    AUTO("auto", "Auto Detect (تلقائي)", "en_GB"),
    ENGLISH_UK("en_GB", "English (UK Butler)", "en_GB"),
    ARABIC("ar", "العربية (فصحى سيدي)", "ar")
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class MessageSender {
    SIR,
    JARVIS
}

data class JarvisSettings(
    val pitch: Float = 0.88f, // Deep Baritone preset as requested
    val speechRate: Float = 0.98f, // Calm, measured pacing
    val language: JarvisLanguage = JarvisLanguage.AUTO,
    val streamingTts: Boolean = true,
    val soundEffectsEnabled: Boolean = true,
    val customApiKey: String = ""
)

data class HudTelemetryData(
    val arcReactorOutput: Int = 100, // percentage
    val cpuUtilization: Int = 12,
    val coreTempCelsius: Int = 36,
    val networkBandwidth: String = "128 Gbps",
    val statusMessage: String = "ALL SYSTEMS OPERATIONAL"
)
