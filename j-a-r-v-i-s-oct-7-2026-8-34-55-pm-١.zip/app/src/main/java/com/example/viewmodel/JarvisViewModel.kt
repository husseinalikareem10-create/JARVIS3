package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.JarvisSoundEffects
import com.example.audio.JarvisSpeechRecognizer
import com.example.audio.JarvisTtsManager
import com.example.model.ChatMessage
import com.example.model.HudTelemetryData
import com.example.model.JarvisLanguage
import com.example.model.JarvisSettings
import com.example.model.JarvisState
import com.example.model.MessageSender
import com.example.network.GeminiClient
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val geminiClient = GeminiClient()
    private val soundEffects = JarvisSoundEffects()

    private val _uiState = MutableStateFlow(JarvisState.STANDBY)
    val uiState: StateFlow<JarvisState> = _uiState.asStateFlow()

    private val _settings = MutableStateFlow(JarvisSettings())
    val settings: StateFlow<JarvisSettings> = _settings.asStateFlow()

    private val _telemetry = MutableStateFlow(HudTelemetryData())
    val telemetry: StateFlow<HudTelemetryData> = _telemetry.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = MessageSender.JARVIS,
                text = "الأنظمة جاهزة، سيدي. مفاعل الآرك يعمل بكفاءة تامة وأنا بانتظار توجيهاتكم الصوتية."
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _currentStreamingResponse = MutableStateFlow("")
    val currentStreamingResponse: StateFlow<String> = _currentStreamingResponse.asStateFlow()

    private val _currentUserQuery = MutableStateFlow("")
    val currentUserQuery: StateFlow<String> = _currentUserQuery.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val ttsManager = JarvisTtsManager(application) { isSpeaking ->
        if (isSpeaking) {
            _uiState.value = JarvisState.SPEAKING
        } else {
            if (_uiState.value == JarvisState.SPEAKING) {
                _uiState.value = JarvisState.STANDBY
            }
        }
    }

    private val speechRecognizer = JarvisSpeechRecognizer(
        context = application,
        onResult = { recognizedText ->
            handleUserInput(recognizedText)
        },
        onError = { err ->
            _errorMessage.value = err
            _uiState.value = JarvisState.STANDBY
        },
        onStateChange = { isListening ->
            if (isListening) {
                _uiState.value = JarvisState.LISTENING
            } else if (_uiState.value == JarvisState.LISTENING) {
                // Keep listening or switch to processing
            }
        }
    )

    val rmsDb: StateFlow<Float> = speechRecognizer.rmsDb

    private var activeStreamJob: Job? = null

    init {
        applySettingsToEngines(_settings.value)
    }

    fun isSpeechRecognitionAvailable(): Boolean {
        return speechRecognizer.isAvailable()
    }

    fun toggleListening() {
        if (_uiState.value == JarvisState.LISTENING) {
            speechRecognizer.stopListening()
            _uiState.value = JarvisState.STANDBY
            if (_settings.value.soundEffectsEnabled) soundEffects.playStandbyClick()
        } else {
            stopAudio()
            _errorMessage.value = null
            _currentUserQuery.value = ""
            if (_settings.value.soundEffectsEnabled) soundEffects.playActivationBeep()
            speechRecognizer.startListening(_settings.value.language.code)
            _uiState.value = JarvisState.LISTENING
        }
    }

    fun stopAudio() {
        activeStreamJob?.cancel()
        ttsManager.stop()
        speechRecognizer.stopListening()
        _uiState.value = JarvisState.STANDBY
    }

    fun handleUserInput(input: String) {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return

        _currentUserQuery.value = trimmed
        _errorMessage.value = null
        stopAudio()

        if (_settings.value.soundEffectsEnabled) soundEffects.playAcknowledgeChime()

        val sirMessage = ChatMessage(sender = MessageSender.SIR, text = trimmed)
        _messages.update { it + sirMessage }

        _uiState.value = JarvisState.PROCESSING
        _currentStreamingResponse.value = ""

        activeStreamJob = viewModelScope.launch {
            val sentenceBuffer = StringBuilder()
            var hasStartedSpeaking = false

            val result = geminiClient.streamGenerate(
                history = _messages.value,
                customKey = _settings.value.customApiKey
            ) { chunk ->
                _currentStreamingResponse.update { it + chunk }

                if (_settings.value.streamingTts) {
                    sentenceBuffer.append(chunk)
                    val bufferStr = sentenceBuffer.toString()
                    val delimiterIndex = findSentenceDelimiter(bufferStr)
                    if (delimiterIndex != -1) {
                        val completeSentence = bufferStr.substring(0, delimiterIndex + 1).trim()
                        val remainder = bufferStr.substring(delimiterIndex + 1)
                        sentenceBuffer.clear()
                        sentenceBuffer.append(remainder)

                        if (completeSentence.isNotBlank()) {
                            ttsManager.speak(completeSentence, isQueueAdd = hasStartedSpeaking)
                            hasStartedSpeaking = true
                        }
                    }
                }
            }

            result.onSuccess { fullText ->
                val finalClean = fullText.trim()
                if (finalClean.isNotEmpty()) {
                    val jarvisMessage = ChatMessage(sender = MessageSender.JARVIS, text = finalClean)
                    _messages.update { it + jarvisMessage }

                    // If streaming TTS wasn't enabled or remaining buffer needs speech
                    if (!_settings.value.streamingTts) {
                        ttsManager.speak(finalClean, isQueueAdd = false)
                    } else if (sentenceBuffer.isNotBlank()) {
                        val remaining = sentenceBuffer.toString().trim()
                        if (remaining.isNotEmpty()) {
                            ttsManager.speak(remaining, isQueueAdd = hasStartedSpeaking)
                        }
                    }
                } else {
                    _uiState.value = JarvisState.STANDBY
                }
            }.onFailure { err ->
                _errorMessage.value = err.message ?: "Processing failure"
                _uiState.value = JarvisState.ERROR
            }
        }
    }

    private fun findSentenceDelimiter(text: String): Int {
        val delimiters = charArrayOf('.', '!', '?', '\n', '،', '؛')
        for (i in text.indices) {
            val c = text[i]
            if (delimiters.contains(c)) {
                // Ensure there's a space or it's at end or newline
                if (i == text.length - 1 || text[i + 1].isWhitespace() || c == '\n') {
                    return i
                }
            }
        }
        return -1
    }

    fun updateSettings(newSettings: JarvisSettings) {
        _settings.value = newSettings
        applySettingsToEngines(newSettings)
    }

    private fun applySettingsToEngines(s: JarvisSettings) {
        ttsManager.updateSettings(
            pitch = s.pitch,
            rate = s.speechRate,
            localePref = s.language.code
        )
    }

    fun executeDirective(directiveTitle: String, prompt: String) {
        handleUserInput(prompt)
    }

    fun dismissError() {
        _errorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        stopAudio()
        ttsManager.release()
        soundEffects.release()
    }
}
