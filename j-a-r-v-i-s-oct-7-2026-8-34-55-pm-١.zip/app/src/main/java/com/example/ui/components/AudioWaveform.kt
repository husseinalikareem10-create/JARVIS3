package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import com.example.model.JarvisState
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisGold
import kotlin.math.sin

@Composable
fun AudioWaveform(
    state: JarvisState,
    rmsAmplitude: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "WaveformAnimation")

    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "WavePhase"
    )

    val baseColor = when (state) {
        JarvisState.LISTENING -> JarvisGold
        JarvisState.SPEAKING -> JarvisCyan
        JarvisState.PROCESSING -> JarvisGold
        JarvisState.ERROR -> Color(0xFFFF1744)
        JarvisState.STANDBY -> JarvisCyan.copy(alpha = 0.6f)
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(44.dp)
    ) {
        val width = size.width
        val height = size.height
        val centerY = height / 2f
        val barCount = 38
        val spacing = width / barCount

        val activityMultiplier = when (state) {
            JarvisState.LISTENING -> (0.25f + rmsAmplitude * 1.5f).coerceIn(0.15f, 1f)
            JarvisState.SPEAKING -> 0.85f
            JarvisState.PROCESSING -> 0.45f
            JarvisState.ERROR -> 0.2f
            JarvisState.STANDBY -> 0.12f
        }

        for (i in 0 until barCount) {
            val x = i * spacing + spacing / 2f
            val normalizedX = i.toFloat() / barCount

            // Dynamic sine fluctuation
            val waveVal = sin(normalizedX * 10f + phase) * sin(normalizedX * 4f)
            val barHeight = ((height * 0.4f) * activityMultiplier * Math.abs(waveVal) + 4f).coerceAtLeast(3f)

            val color = if (i % 2 == 0) baseColor else baseColor.copy(alpha = 0.75f)

            drawLine(
                color = color,
                start = Offset(x, centerY - barHeight),
                end = Offset(x, centerY + barHeight),
                strokeWidth = 3f,
                cap = StrokeCap.Round
            )
        }
    }
}
