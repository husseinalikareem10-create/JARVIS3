package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// J.A.R.V.I.S. Holographic Arc Reactor Palette
val JarvisBackground = Color(0xFF050B14)
val JarvisSurface = Color(0xFF0A1526)
val JarvisSurfaceVariant = Color(0xFF102038)
val JarvisSurfaceBorder = Color(0xFF1E3A5F)

val JarvisCyan = Color(0xFF00E5FF)
val JarvisCyanDim = Color(0xFF00838F)
val JarvisCyanGlow = Color(0x6600E5FF)

val JarvisGold = Color(0xFFFFB300)
val JarvisGoldDim = Color(0xFFFF8F00)
val JarvisGoldGlow = Color(0x66FFB300)

val JarvisAlertRed = Color(0xFFFF1744)
val JarvisSuccessGreen = Color(0xFF00E676)

val JarvisTextPrimary = Color(0xFFE1F5FE)
val JarvisTextSecondary = Color(0xFF81D4FA)
val JarvisTextMuted = Color(0xFF4FC3F7).copy(alpha = 0.6f)
