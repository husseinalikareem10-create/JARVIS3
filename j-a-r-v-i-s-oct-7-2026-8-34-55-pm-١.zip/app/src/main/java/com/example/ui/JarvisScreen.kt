package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.ChatMessage
import com.example.model.JarvisState
import com.example.model.MessageSender
import com.example.ui.components.ArcReactorView
import com.example.ui.components.AudioWaveform
import com.example.ui.components.HudStatusBanner
import com.example.ui.components.HudTelemetryStrip
import com.example.ui.components.HudTopHeader
import com.example.ui.components.SettingsSheet
import com.example.ui.theme.JarvisAlertRed
import com.example.ui.theme.JarvisBackground
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.JarvisSurfaceBorder
import com.example.ui.theme.JarvisTextMuted
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import com.example.viewmodel.JarvisViewModel

@Composable
fun JarvisScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val telemetry by viewModel.telemetry.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val rmsAmplitude by viewModel.rmsDb.collectAsState()
    val streamingChunk by viewModel.currentStreamingResponse.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var showSettings by remember { mutableStateOf(false) }
    var textInputExpanded by remember { mutableStateOf(false) }
    var textQuery by remember { mutableStateOf("") }
    val snackbarHostState = remember { SnackbarHostState() }

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (granted) {
            viewModel.toggleListening()
        }
    }

    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissError()
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisBackground),
        containerColor = JarvisBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top HUD Header
                HudTopHeader(
                    state = uiState,
                    onOpenSettings = { showSettings = true }
                )

                // Telemetry Strip
                HudTelemetryStrip(
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                // Status Banner
                HudStatusBanner(
                    state = uiState,
                    telemetry = telemetry,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Arc Reactor Centerpiece
                ArcReactorView(
                    state = uiState,
                    rmsAmplitude = rmsAmplitude,
                    reactorSize = 210.dp,
                    onClick = {
                        if (!hasMicPermission) {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        } else {
                            viewModel.toggleListening()
                        }
                    }
                )

                // Arc Reactor Helper Label
                Text(
                    text = when (uiState) {
                        JarvisState.LISTENING -> "TAP TO COMPLETE VOCAL COMMAND"
                        JarvisState.SPEAKING -> "TAP TO INTERRUPT SPEECH"
                        JarvisState.PROCESSING -> "ANALYZING TACTICAL DIRECTIVE..."
                        JarvisState.STANDBY -> "TAP ARC REACTOR TO ENGAGE VOICE"
                        JarvisState.ERROR -> "SYSTEM ALERT - TAP TO RESTART"
                    },
                    color = when (uiState) {
                        JarvisState.LISTENING -> JarvisGold
                        JarvisState.SPEAKING -> JarvisCyan
                        JarvisState.ERROR -> JarvisAlertRed
                        else -> JarvisTextSecondary
                    },
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.1.sp,
                    modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                )

                // Audio Waveform
                AudioWaveform(
                    state = uiState,
                    rmsAmplitude = rmsAmplitude,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
                )

                // Tactical Command Chips
                TacticalDirectivesRow(
                    onDirectiveSelected = { directiveTitle, prompt ->
                        viewModel.executeDirective(directiveTitle, prompt)
                    },
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                // Spoken Transcript Feed
                TranscriptCard(
                    messages = messages,
                    streamingChunk = streamingChunk,
                    uiState = uiState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                )

                // Manual Text Input Box (Collapsible)
                AnimatedVisibility(
                    visible = textInputExpanded,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = textQuery,
                            onValueChange = { textQuery = it },
                            placeholder = {
                                Text(
                                    "Type directive for Sir...",
                                    color = JarvisTextSecondary.copy(alpha = 0.5f),
                                    fontSize = 13.sp
                                )
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = JarvisCyan,
                                unfocusedBorderColor = JarvisSurfaceBorder,
                                focusedTextColor = JarvisTextPrimary,
                                unfocusedTextColor = JarvisTextPrimary,
                                cursorColor = JarvisCyan
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("manual_text_input")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                if (textQuery.isNotBlank()) {
                                    viewModel.handleUserInput(textQuery)
                                    textQuery = ""
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(JarvisCyan)
                                .testTag("send_manual_query_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send",
                                tint = JarvisBackground,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Bottom Control Action Bar
                BottomControlBar(
                    uiState = uiState,
                    hasPermission = hasMicPermission,
                    isTextExpanded = textInputExpanded,
                    onToggleMic = {
                        if (!hasMicPermission) {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        } else {
                            viewModel.toggleListening()
                        }
                    },
                    onStopAudio = { viewModel.stopAudio() },
                    onToggleTextInput = { textInputExpanded = !textInputExpanded },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp, top = 4.dp)
                )
            }

            // Settings Sheet
            if (showSettings) {
                SettingsSheet(
                    settings = settings,
                    onSaveSettings = { viewModel.updateSettings(it) },
                    onDismiss = { showSettings = false }
                )
            }
        }
    }
}

@Composable
private fun TacticalDirectivesRow(
    onDirectiveSelected: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val directives = listOf(
        "فحص الأنظمة" to "أجرِ فحصاً تشخيصياً كاملاً لجميع الأنظمة ومفاعل الآرك، سيدي يريد التقرير الآن.",
        "حالة المفاعل" to "ما هي حالة كفاءة مفاعل الآرك ودرجة حرارة النواة الحالية؟",
        "تقييم التهديدات" to "قم بإجراء مسح أمني شامل وتقييم للمخاطر المحيطة بنا فوراً.",
        "درع مارك 7" to "أبلغني بحالة درع مارك سبعة وجاهزية أنظمة الطيران والأسلحة الدفاعية.",
        "من أنت يا جارفيس؟" to "عرّف نفسك يا جارفيس، واشرح دورك في مساعدة مبتكرك.",
        "Mark VII Status" to "JARVIS, report Mark VII armor readiness and flight thrusters.",
        "Threat Assessment" to "Analyze tactical perimeter for immediate hazards."
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        directives.forEach { (title, prompt) ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(JarvisSurface.copy(alpha = 0.8f))
                    .border(BorderStroke(1.dp, JarvisCyan.copy(alpha = 0.4f)), RoundedCornerShape(16.dp))
                    .clickable { onDirectiveSelected(title, prompt) }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .testTag("directive_chip_${title.replace(" ", "_")}")
            ) {
                Text(
                    text = title,
                    color = JarvisCyan,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun TranscriptCard(
    messages: List<ChatMessage>,
    streamingChunk: String,
    uiState: JarvisState,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, streamingChunk) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = JarvisSurface.copy(alpha = 0.75f)),
        border = BorderStroke(1.dp, JarvisSurfaceBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "VOCAL TRANSCRIPT & TELEMETRY",
                    color = JarvisCyan,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.1.sp
                )
                if (uiState == JarvisState.SPEAKING) {
                    Text(
                        text = "● AUDIO LIVE",
                        color = JarvisGold,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    TranscriptBubble(message = msg)
                }

                if (streamingChunk.isNotBlank() && uiState == JarvisState.PROCESSING) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(JarvisCyan.copy(alpha = 0.08f))
                                .border(BorderStroke(0.8.dp, JarvisCyan.copy(alpha = 0.3f)), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "J.A.R.V.I.S.: $streamingChunk...",
                                color = JarvisTextPrimary,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TranscriptBubble(message: ChatMessage) {
    val isSir = message.sender == MessageSender.SIR
    val bubbleColor = if (isSir) JarvisSurfaceBorder.copy(alpha = 0.5f) else JarvisCyan.copy(alpha = 0.12f)
    val borderColor = if (isSir) JarvisGold.copy(alpha = 0.4f) else JarvisCyan.copy(alpha = 0.4f)
    val tagColor = if (isSir) JarvisGold else JarvisCyan
    val senderLabel = if (isSir) "SIR [CREATOR]" else "J.A.R.V.I.S."

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(bubbleColor)
            .border(BorderStroke(0.8.dp, borderColor), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Text(
            text = senderLabel,
            color = tagColor,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = message.text,
            color = JarvisTextPrimary,
            fontSize = 13.sp,
            lineHeight = 18.sp
        )
    }
}

@Composable
private fun BottomControlBar(
    uiState: JarvisState,
    hasPermission: Boolean,
    isTextExpanded: Boolean,
    onToggleMic: () -> Unit,
    onStopAudio: () -> Unit,
    onToggleTextInput: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Text Input Toggle Button
        IconButton(
            onClick = onToggleTextInput,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(if (isTextExpanded) JarvisCyan.copy(alpha = 0.2f) else JarvisSurface)
                .border(BorderStroke(1.dp, JarvisSurfaceBorder), CircleShape)
                .testTag("toggle_keyboard_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Chat,
                contentDescription = "Manual Text Input",
                tint = if (isTextExpanded) JarvisCyan else JarvisTextSecondary
            )
        }

        // Primary Mic / Reactor Engage Button
        val micButtonColor = when (uiState) {
            JarvisState.LISTENING -> JarvisGold
            JarvisState.SPEAKING -> JarvisCyan
            JarvisState.PROCESSING -> JarvisGold
            JarvisState.ERROR -> JarvisAlertRed
            JarvisState.STANDBY -> JarvisCyan
        }

        Button(
            onClick = onToggleMic,
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = micButtonColor,
                contentColor = JarvisBackground
            ),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp),
            modifier = Modifier
                .height(48.dp)
                .testTag("primary_mic_button")
        ) {
            Icon(
                imageVector = if (uiState == JarvisState.LISTENING) Icons.Default.MicOff else Icons.Default.Mic,
                contentDescription = "Toggle Speech Recognition",
                tint = JarvisBackground,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = when (uiState) {
                    JarvisState.LISTENING -> "DISENGAGE"
                    JarvisState.PROCESSING -> "COMPUTING"
                    JarvisState.SPEAKING -> "TRANSMITTING"
                    else -> "ENGAGE SIR"
                },
                color = JarvisBackground,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.sp,
                letterSpacing = 1.1.sp
            )
        }

        // Interrupt / Stop Audio Button
        IconButton(
            onClick = onStopAudio,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(JarvisSurface)
                .border(BorderStroke(1.dp, JarvisSurfaceBorder), CircleShape)
                .testTag("stop_audio_button")
        ) {
            Icon(
                imageVector = Icons.Default.Stop,
                contentDescription = "Silence Audio",
                tint = if (uiState == JarvisState.SPEAKING || uiState == JarvisState.LISTENING) JarvisAlertRed else JarvisTextSecondary
            )
        }
    }
}
