package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.JarvisState
import com.example.ui.theme.JarvisAlertRed
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisCyanGlow
import com.example.ui.theme.JarvisGold
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactorView(
    state: JarvisState,
    rmsAmplitude: Float,
    modifier: Modifier = Modifier,
    reactorSize: Dp = 240.dp,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ArcReactorMotion")

    // Outer ring rotation
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "OuterRotation"
    )

    // Inner counter rotation
    val counterRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "InnerCounterRotation"
    )

    // Breathing pulse
    val breathingPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BreathingPulse"
    )

    val activeColor = when (state) {
        JarvisState.ERROR -> JarvisAlertRed
        JarvisState.LISTENING -> JarvisGold
        JarvisState.SPEAKING -> JarvisCyan
        JarvisState.PROCESSING -> JarvisGold
        JarvisState.STANDBY -> JarvisCyan
    }

    val dynamicPulse = if (state == JarvisState.LISTENING) {
        breathingPulse * (1f + rmsAmplitude * 0.45f)
    } else if (state == JarvisState.SPEAKING) {
        breathingPulse * 1.1f
    } else {
        breathingPulse
    }

    Box(
        modifier = modifier
            .size(reactorSize)
            .testTag("arc_reactor_touch_target")
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = reactorSize / 2),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = (size.minDimension / 2f) * 0.92f

            drawArcReactor(
                center = center,
                baseRadius = radius,
                rotationAngle = rotationAngle,
                counterRotation = counterRotation,
                pulseScale = dynamicPulse,
                themeColor = activeColor,
                state = state
            )
        }
    }
}

private fun DrawScope.drawArcReactor(
    center: Offset,
    baseRadius: Float,
    rotationAngle: Float,
    counterRotation: Float,
    pulseScale: Float,
    themeColor: Color,
    state: JarvisState
) {
    val glowColor = themeColor.copy(alpha = 0.35f)

    // Outer Aura Glow
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(glowColor, Color.Transparent),
            center = center,
            radius = baseRadius * 1.25f * pulseScale
        ),
        radius = baseRadius * 1.25f * pulseScale,
        center = center
    )

    // 1. Outermost segmented reticle ring
    val outerRingRadius = baseRadius * 0.95f
    val segmentCount = 36
    val segmentStep = 360f / segmentCount
    for (i in 0 until segmentCount) {
        val angleDeg = i * segmentStep + rotationAngle
        val angleRad = Math.toRadians(angleDeg.toDouble())
        val isMajor = (i % 3 == 0)
        val tickLen = if (isMajor) 10f else 5f
        val startR = outerRingRadius - tickLen
        val startX = center.x + (startR * cos(angleRad)).toFloat()
        val startY = center.y + (startR * sin(angleRad)).toFloat()
        val endX = center.x + (outerRingRadius * cos(angleRad)).toFloat()
        val endY = center.y + (outerRingRadius * sin(angleRad)).toFloat()

        drawLine(
            color = themeColor.copy(alpha = if (isMajor) 0.8f else 0.3f),
            start = Offset(startX, startY),
            end = Offset(endX, endY),
            strokeWidth = if (isMajor) 2.5f else 1.2f,
            cap = StrokeCap.Round
        )
    }

    // 2. Main Outer Structural Ring
    drawCircle(
        color = themeColor,
        radius = baseRadius * 0.82f,
        center = center,
        style = Stroke(width = 3.5f)
    )

    // 3. Ten Palladium / Copper Energy Coils
    val coilCount = 10
    val coilStep = 360f / coilCount
    val coilDistance = baseRadius * 0.72f
    for (i in 0 until coilCount) {
        val coilAngle = Math.toRadians((i * coilStep + counterRotation).toDouble())
        val coilX = center.x + (coilDistance * cos(coilAngle)).toFloat()
        val coilY = center.y + (coilDistance * sin(coilAngle)).toFloat()

        // Coil casing (Stark Amber Gold or Cyan)
        val coilColor = if (state == JarvisState.LISTENING) JarvisGold else JarvisCyan
        drawCircle(
            color = coilColor,
            radius = 6f * pulseScale,
            center = Offset(coilX, coilY)
        )
        drawCircle(
            color = Color.White,
            radius = 2.5f,
            center = Offset(coilX, coilY)
        )
    }

    // 4. Middle Arc Ring with Dashed/Gap pattern
    drawCircle(
        color = themeColor.copy(alpha = 0.65f),
        radius = baseRadius * 0.60f,
        center = center,
        style = Stroke(width = 2.5f)
    )

    // 5. Triangular Arc Core Inner Chassis
    val triRadius = baseRadius * 0.44f * pulseScale
    val path = Path()
    for (i in 0 until 3) {
        val vertexAngle = Math.toRadians((i * 120.0 - 90.0 + rotationAngle * 0.5))
        val vx = center.x + (triRadius * cos(vertexAngle)).toFloat()
        val vy = center.y + (triRadius * sin(vertexAngle)).toFloat()
        if (i == 0) path.moveTo(vx, vy) else path.lineTo(vx, vy)
    }
    path.close()
    drawPath(
        path = path,
        color = themeColor.copy(alpha = 0.85f),
        style = Stroke(width = 3f)
    )

    // 6. Central Arc Reactor Core Glow & Center Dot
    val coreRadius = baseRadius * 0.26f * pulseScale
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color.White, themeColor, themeColor.copy(alpha = 0.2f), Color.Transparent),
            center = center,
            radius = coreRadius * 1.5f
        ),
        radius = coreRadius * 1.5f,
        center = center
    )

    drawCircle(
        color = Color.White,
        radius = baseRadius * 0.12f * pulseScale,
        center = center
    )
}
