package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.JarvisLanguage
import com.example.model.JarvisSettings
import com.example.ui.theme.JarvisBackground
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.JarvisSurfaceBorder
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    settings: JarvisSettings,
    onSaveSettings: (JarvisSettings) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var pitch by remember { mutableFloatStateOf(settings.pitch) }
    var speechRate by remember { mutableFloatStateOf(settings.speechRate) }
    var selectedLanguage by remember { mutableStateOf(settings.language) }
    var streamingTts by remember { mutableStateOf(settings.streamingTts) }
    var soundEffectsEnabled by remember { mutableStateOf(settings.soundEffectsEnabled) }
    var customApiKey by remember { mutableStateOf(settings.customApiKey) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = JarvisSurface,
        scrimColor = Color.Black.copy(alpha = 0.7f),
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "NEURAL VOICE ENGINE",
                        color = JarvisCyan,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "PROTOCOL CONFIGURATION",
                        color = JarvisTextPrimary,
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = JarvisCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Baritone Pitch Control
            SettingsSectionHeader(
                icon = Icons.Default.GraphicEq,
                title = "VOICE PITCH (BARITONE TIMBRE)",
                subtitle = "Deep warm baritone preset (0.85x - 0.90x recommended)"
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Slider(
                    value = pitch,
                    onValueChange = { pitch = it },
                    valueRange = 0.65f..1.35f,
                    steps = 14,
                    colors = SliderDefaults.colors(
                        thumbColor = JarvisCyan,
                        activeTrackColor = JarvisCyan,
                        inactiveTrackColor = JarvisSurfaceBorder
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("pitch_slider")
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = String.format("%.2fx", pitch),
                    color = JarvisGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Speech Rate Control
            SettingsSectionHeader(
                icon = Icons.Default.Speed,
                title = "SPEECH RATE (PACING)",
                subtitle = "Calm, polite butler delivery speed"
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Slider(
                    value = speechRate,
                    onValueChange = { speechRate = it },
                    valueRange = 0.75f..1.4f,
                    steps = 13,
                    colors = SliderDefaults.colors(
                        thumbColor = JarvisCyan,
                        activeTrackColor = JarvisCyan,
                        inactiveTrackColor = JarvisSurfaceBorder
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("rate_slider")
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = String.format("%.2fx", speechRate),
                    color = JarvisGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Language Selector
            SettingsSectionHeader(
                icon = Icons.Default.Translate,
                title = "TACTICAL DIALECT & LOCALE",
                subtitle = "Language mode for voice recognition & responses"
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                JarvisLanguage.entries.forEach { lang ->
                    val isSelected = selectedLanguage == lang
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) JarvisCyan.copy(alpha = 0.15f) else JarvisBackground)
                            .border(
                                BorderStroke(
                                    1.dp,
                                    if (isSelected) JarvisCyan else JarvisSurfaceBorder
                                ),
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { selectedLanguage = lang }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                            .testTag("lang_option_${lang.name}"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = lang.displayName,
                            color = if (isSelected) JarvisCyan else JarvisTextPrimary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 14.sp
                        )
                        if (isSelected) {
                            Text(
                                text = "ACTIVE",
                                color = JarvisGold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Streaming TTS toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "LOW-LATENCY STREAMING TTS",
                        color = JarvisTextPrimary,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Generates spoken audio sentence-by-sentence in real time",
                        color = JarvisTextSecondary,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = streamingTts,
                    onCheckedChange = { streamingTts = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = JarvisCyan,
                        checkedTrackColor = JarvisCyan.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.testTag("streaming_switch")
                )
            }

            // HUD Sound effects toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "STARK HUD SOUND EFFECTS",
                        color = JarvisTextPrimary,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Auditory confirmation chimes and activation pulses",
                        color = JarvisTextSecondary,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = soundEffectsEnabled,
                    onCheckedChange = { soundEffectsEnabled = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = JarvisGold,
                        checkedTrackColor = JarvisGold.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.testTag("sound_effects_switch")
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Gemini API Key Override Field
            SettingsSectionHeader(
                icon = Icons.Default.Key,
                title = "GEMINI API KEY OVERRIDE",
                subtitle = "Injected via Secrets panel or customize directly below"
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = customApiKey,
                onValueChange = { customApiKey = it },
                placeholder = {
                    Text("Enter Gemini API key (optional)", color = JarvisTextSecondary.copy(alpha = 0.5f))
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = JarvisCyan,
                    unfocusedBorderColor = JarvisSurfaceBorder,
                    focusedTextColor = JarvisTextPrimary,
                    unfocusedTextColor = JarvisTextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("custom_api_key_field")
            )

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedButton(
                onClick = {
                    onSaveSettings(
                        settings.copy(
                            pitch = pitch,
                            speechRate = speechRate,
                            language = selectedLanguage,
                            streamingTts = streamingTts,
                            soundEffectsEnabled = soundEffectsEnabled,
                            customApiKey = customApiKey
                        )
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = JarvisCyan
                ),
                border = BorderStroke(1.5.dp, JarvisCyan),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_settings_button")
            ) {
                Text(
                    text = "CONFIRM & SYNC PROTOCOLS",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SettingsSectionHeader(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = JarvisCyan,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = title,
                color = JarvisCyan,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.1.sp
            )
            Text(
                text = subtitle,
                color = JarvisTextSecondary,
                fontSize = 10.sp
            )
        }
    }
}
