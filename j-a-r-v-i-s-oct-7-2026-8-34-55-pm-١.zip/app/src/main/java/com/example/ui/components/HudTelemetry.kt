package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HudTelemetryData
import com.example.model.JarvisState
import com.example.ui.theme.JarvisAlertRed
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.JarvisSurfaceBorder
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary

@Composable
fun HudTopHeader(
    state: JarvisState,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(
                            when (state) {
                                JarvisState.ERROR -> JarvisAlertRed
                                JarvisState.LISTENING -> JarvisGold
                                JarvisState.SPEAKING -> JarvisCyan
                                JarvisState.PROCESSING -> JarvisGold
                                JarvisState.STANDBY -> JarvisCyan
                            }
                        )
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "STARK IND. // AI CORE",
                    color = JarvisCyan,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            }
            Text(
                text = "J.A.R.V.I.S. PROTOCOL",
                color = JarvisTextPrimary,
                fontSize = 18.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.5.sp
            )
        }

        IconButton(
            onClick = onOpenSettings,
            modifier = Modifier
                .size(48.dp)
                .testTag("settings_button")
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Protocol Settings",
                tint = JarvisCyan,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun HudStatusBanner(
    state: JarvisState,
    telemetry: HudTelemetryData,
    modifier: Modifier = Modifier
) {
    val statusText = when (state) {
        JarvisState.LISTENING -> "LISTENING TO SIR..."
        JarvisState.PROCESSING -> "COMPUTING NEURAL RESPONSE..."
        JarvisState.SPEAKING -> "TRANSMITTING VOCAL AUDIO..."
        JarvisState.ERROR -> "SYSTEM WARNING DETECTED"
        JarvisState.STANDBY -> telemetry.statusMessage
    }

    val bannerColor = when (state) {
        JarvisState.ERROR -> JarvisAlertRed
        JarvisState.LISTENING -> JarvisGold
        JarvisState.PROCESSING -> JarvisGold
        JarvisState.SPEAKING -> JarvisCyan
        JarvisState.STANDBY -> JarvisCyan
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(JarvisSurface.copy(alpha = 0.85f))
            .border(BorderStroke(1.dp, bannerColor.copy(alpha = 0.5f)), RoundedCornerShape(8.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "● ",
                color = bannerColor,
                fontSize = 12.sp
            )
            Text(
                text = statusText,
                color = bannerColor,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.1.sp
            )
        }
    }
}

@Composable
fun HudTelemetryStrip(
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        TelemetryBadge(
            icon = Icons.Default.Bolt,
            label = "ARC CORE",
            value = "100%",
            color = JarvisCyan
        )
        TelemetryBadge(
            icon = Icons.Default.RecordVoiceOver,
            label = "VOICE ENGINE",
            value = "BARITONE",
            color = JarvisGold
        )
        TelemetryBadge(
            icon = Icons.Default.Shield,
            label = "SECURITY",
            value = "STARK-SEC",
            color = JarvisCyan
        )
    }
}

@Composable
private fun TelemetryBadge(
    icon: ImageVector,
    label: String,
    value: String,
    color: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(JarvisSurface.copy(alpha = 0.6f))
            .border(BorderStroke(0.8.dp, JarvisSurfaceBorder), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Column {
            Text(
                text = label,
                color = JarvisTextSecondary.copy(alpha = 0.7f),
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = value,
                color = color,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
