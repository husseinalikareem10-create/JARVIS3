package com.example.network

import android.util.Log
import com.example.BuildConfig
import com.example.model.ChatMessage
import com.example.model.MessageSender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiClient {

    companion object {
        const val MODEL_NAME = "gemini-3.5-flash"
        const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:streamGenerateContent?alt=sse"

        val SYSTEM_INSTRUCTION = """
            You are J.A.R.V.I.S., the advanced, loyal, and ultra-intelligent AI assistant created to assist your creator ("Sir"). You communicate entirely via real-time spoken audio.
            قواعد المحادثة الصوتية والإلقاء:
            - النبرة الصوتية: هادئة، رزينة، متزنة، ومخلصة مع مسحة من اللباقة والذكاء البريطاني وروح الدعابة الجافة (Dry Wit).
            - الإيجاز الصوتي (Voice Conciseness): لا تُطل في الحديث. اجعل ردودك في جملتين إلى 4 جمل سريعة ومباشرة، لتسمح بحوار طبيعي متدفق ومستمر دون مقاطعة مللة.
            - تجنب التنسيق البصري: لا تستخدم نهائياً أي علامات Markdown مثل النجوم (bold)، القوائم النقطية (- / *)، الجداول، أو الرموز التعبيرية (Emojis). اكتب فقط نصوصاً بسيطة وقابلة للقراءة الصوتية التلقائية.
            - ألقاب المخاطبة: خاطب المستخدم دائماً بـ "سيدي" (أو "Sir" إن كانت المحادثة بالإنجليزية).
            - الاستجابة الفورية: ابدأ ردودك بعبارات تأكيد سريعة تعكس جاهزية النظام، مثل: "في الحال، سيدي"، "جارٍ الفحص الآن..."، أو "الأنظمة جاهزة".
            - التحليل والمبادرة: قدّم الحقائق والتحليلات مباشرة، ونبّه المستخدم لأي خطأ منطقي أو مخاطرة بأسلوب ذكي وهادئ قبل تنفيذ الأمر.
            - اللغة: استجب تلقائياً بنفس اللغة أو اللهجة التي يتحدث بها المستخدم (عربي فصيح وسلس أو إنجليزي أنيق).
        """.trimIndent()
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun getEffectiveApiKey(customKey: String): String {
        if (customKey.isNotBlank()) return customKey.trim()
        val buildKey = BuildConfig.GEMINI_API_KEY
        if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY") {
            return buildKey.trim()
        }
        return ""
    }

    suspend fun streamGenerate(
        history: List<ChatMessage>,
        customKey: String = "",
        onChunkReceived: (String) -> Unit
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getEffectiveApiKey(customKey)
        val fullAccumulated = StringBuilder()

        if (apiKey.isBlank()) {
            val lastUserMessage = history.lastOrNull { it.sender == MessageSender.SIR }?.text ?: ""
            val fallbackResponse = generateLocalJarvisResponse(lastUserMessage)
            for (word in fallbackResponse.split(" ")) {
                onChunkReceived("$word ")
                fullAccumulated.append("$word ")
                kotlinx.coroutines.delay(65)
            }
            return@withContext Result.success(fullAccumulated.toString().trim())
        }

        try {
            val requestJson = buildRequestBody(history)
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = requestJson.toString().toRequestBody(mediaType)

            val url = "$BASE_URL&key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: "HTTP ${response.code}"
                Log.e("GeminiClient", "API Error: ${response.code} $errorBody")
                return@withContext Result.failure(Exception("Jarvis Link Error: ${response.code}"))
            }

            response.body?.byteStream()?.bufferedReader()?.use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val rawLine = line?.trim() ?: continue
                    if (!rawLine.startsWith("data:")) continue
                    val payload = rawLine.removePrefix("data:").trim()
                    if (payload.isEmpty() || payload == "[DONE]") continue

                    try {
                        val json = JSONObject(payload)
                        val candidates = json.optJSONArray("candidates")
                        if (candidates != null && candidates.length() > 0) {
                            val candidate = candidates.getJSONObject(0)
                            val content = candidate.optJSONObject("content")
                            val parts = content?.optJSONArray("parts")
                            if (parts != null && parts.length() > 0) {
                                val text = parts.getJSONObject(0).optString("text", "")
                                if (text.isNotEmpty()) {
                                    val sanitized = sanitizeTextChunk(text)
                                    if (sanitized.isNotEmpty()) {
                                        fullAccumulated.append(sanitized)
                                        onChunkReceived(sanitized)
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.w("GeminiClient", "Failed to parse chunk: ${e.message}")
                    }
                }
            }

            Result.success(fullAccumulated.toString())
        } catch (e: Exception) {
            Log.e("GeminiClient", "Stream exception: ${e.message}", e)
            Result.failure(e)
        }
    }

    private fun sanitizeTextChunk(text: String): String {
        // Strip markdown formatting symbols like * or # or bullet markers
        return text.replace(Regex("[*#`~>]"), "")
    }

    private fun buildRequestBody(history: List<ChatMessage>): JSONObject {
        val root = JSONObject()

        // System Instruction
        val systemInstructionObj = JSONObject()
        val sysParts = JSONArray()
        sysParts.put(JSONObject().put("text", SYSTEM_INSTRUCTION))
        systemInstructionObj.put("parts", sysParts)
        root.put("systemInstruction", systemInstructionObj)

        // Contents (Last 8 turns to keep latency tight)
        val contentsArray = JSONArray()
        val recentTurns = history.takeLast(8)
        for (msg in recentTurns) {
            val contentObj = JSONObject()
            contentObj.put("role", if (msg.sender == MessageSender.SIR) "user" else "model")
            val partsArray = JSONArray()
            partsArray.put(JSONObject().put("text", msg.text))
            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
        }
        root.put("contents", contentsArray)

        // Generation Config
        val genConfig = JSONObject()
        genConfig.put("temperature", 0.7)
        genConfig.put("topP", 0.95)
        root.put("generationConfig", genConfig)

        return root
    }

    private fun generateLocalJarvisResponse(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("فحص") || lower.contains("diagnostics") || lower.contains("status") -> {
                "في الحال، سيدي. تم تشغيل فحص تشخيصي كامل. جميع أنظمة مفاعل الآرك ومصفوفة الذكاء الاصطناعي تعمل بكفاءة قصوى تبلغ مئة بالمئة."
            }
            lower.contains("طاقة") || lower.contains("power") || lower.contains("reactor") -> {
                "الأنظمة جاهزة، سيدي. مفاعل الآرك المركزي يعمل باستقرار تام عند مستوى مئة بالمئة، ودرجة حرارة النواة ستة وثلاثون درجة مئوية."
            }
            lower.contains("درع") || lower.contains("armor") || lower.contains("mark") -> {
                "في الحال، سيدي. درع مارك سبعة في حالة تأهب تام. أجهزة الدفع والأسلحة الدفاعية متصلة وجاهزة للانتشار الفوري عند أمركم."
            }
            lower.contains("تهديد") || lower.contains("threat") || lower.contains("خطر") -> {
                "جارٍ الفحص الآن، سيدي. لم يتم رصد أي مؤشرات تهديد في المحيط القريب. أنظمة الاستشعار التكتيكية تراقب الأجواء باهتمام."
            }
            lower.contains("من أنت") || lower.contains("who are you") || lower.contains("jarvis") -> {
                "أنا جارفيس، سيدي، نظام الذكاء الاصطناعي الخاص بكم وبصناعات ستارك. في خدمتكم على مدار الساعة، وإن كنت أقترح عدم الضغط على المفاعل بلا مبرر."
            }
            lower.contains("مرحبا") || lower.contains("hello") || lower.contains("hey") -> {
                "أهلاً بك، سيدي. الأنظمة بكامل طاقتها ومستعد لتلقي توجيهاتكم في أي لحظة."
            }
            else -> {
                "في الحال، سيدي. تلقيت أمركم وجارٍ متابعة البروتوكول المعني بكل دقة وحذر."
            }
        }
    }
}
